
export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  link: string;
}
